import { Injectable } from '@nestjs/common';
import * as TelegramBot from 'node-telegram-bot-api';
import { getConfig } from '../utils/config.utils';

@Injectable()
export class BotService {
  constructor() {
    this.start();
  }

  async start() {
    const bot = new TelegramBot(process.env.BOT_TOKEN, { polling: true });
    // Load application settings from the local config file. This allows
    // dynamic substitution of the minimum order price and delivery cost in
    // the welcome message without hard‑coding these values in the source code.
    const config = getConfig();

    bot.on('message', async (msg) => {
      // Ignore messages from other bots or group chats
      if (
        msg.from.is_bot ||
        msg.chat.type === 'group' ||
        msg.chat.type === 'supergroup'
      )
        return;

      await bot.sendDocument(msg.chat.id, process.env.START_MESSAGE_FILE_ID, {
        // Compose a welcome message tailored for a clothing store. The
        // customer’s first name is inserted automatically. Information about
        // the minimum order amount and delivery cost is pulled from the
        // configuration file. Feel free to adjust the wording or emoji to
        // match your brand.
        caption: `${msg.from.first_name}, Добро пожаловать в наш магазин одежды! 🧥👗👚\n\nКак оформить заказ?\n\n☑️ Нажмите «Перейти к заказу»\n☑️ Выберите вещи, которые хотите заказать\n☑️ Укажите количество и адрес доставки\n☑️ Определитесь со способом оплаты\n\n🔸 минимальная сумма заказа — ${config.min_order_price}₽\n🔸 стоимость доставки — ${config.delivery_price}₽\n\nИтак, нажмите «Перейти к заказу»`,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: 'Перейти к заказу',
                web_app: {
                  url: process.env.MINI_APP_STATIC_URL,
                },
              },
            ],
          ],
        },
      });
    });
  }
}
