const getCurrentTimestamp = (): number => Math.floor(Date.now() / 1000);

export default getCurrentTimestamp;
